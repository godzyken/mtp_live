package com.godzy.mtp_live

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
